<?php


$products = [
    [
        "id" => 1,
        "name" => "Chocolati Peanut Butter 510g (No artificial color or flavouring)",
        "price" => 1250,
        "image" => "https://dahabfoods.com/cdn/shop/files/Chocolati_peanut_butter_Pakistan_1776237013.webp?v=1776237156&width=1100"
    ],
    [
        "id" => 2,
        "name" => "Gurr & Sesame seeds Peanut Butter 510g (No artificial color or flavouring)",
        "price" => 1200,
        "image" => "https://dahabfoods.com/cdn/shop/files/peanut-butter-with-gurr_sesameseeds-510g-Pakistan_1776237018.webp?v=1776237159&width=1100"
    ],
    [
        "id" => 3,
        "name" => "Pure (Creamy) Peanut Butter - 1300g or 1.3KG – (No added Salt or Sugar)",
        "price" => 2500,
        "image" => "https://dahabfoods.com/cdn/shop/files/1_81b03c1f-2615-4c6f-8fb8-70b60eb5372b_1776236921.webp?v=1776237094&width=1100"
    ],
    [
        "id" => 4,
        "name" => "Pure Crunchy Peanut Butter 500g (No added Salt or Sugar)",
        "price" => 1190,
        "image" => "https://dahabfoods.com/cdn/shop/files/Pure-Peanut-Butter-500g-Pakistan_1776236930.webp?v=1776237101&width=1100"
    ],
    [
        "id" => 5,
        "name" => "Sweet N Salty Peanut Butter 510g Creamy + 510g Creamy = 1KG total Sweet & Salty",
        "price" => 1899,
        "image" => "https://dahabfoods.com/cdn/shop/files/5.webp?v=1778915775&width=1100"
    ],
    [
        "id" => 6,
        "name" => "1 KG Pure Peanut Butter 500g Creamy + 500g Crunchy = 1KG total | No added Sugar or Salt",
        "price" => 1980,
        "image" => "https://dahabfoods.com/cdn/shop/files/10.webp?v=1778915775&width=1100"
    ],
    [
        "id" => 7,
        "name" => "Chocolati Peanut Butter 340g + Sweet N Salty Peanut Butter Creamy 510g",
        "price" => 1915,
        "image" => "https://dahabfoods.com/cdn/shop/files/12.webp?v=1778915775&width=1100"
    ],
    [
        "id" => 8,
        "name" => "Peanut Butter 340g X4",
        "price" => 2950,
        "image" => "https://dahabfoods.com/cdn/shop/files/12_1776237006.webp?v=1776237152&width=1100"
    ],


    
];

?>