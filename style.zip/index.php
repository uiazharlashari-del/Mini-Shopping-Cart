<?php
session_start();
// Make sure this file exists and contains $products array
include "products.php"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Shop</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<header>
    <h2>DahabFoods</h2>
    <button id="cartBtn">
        <i class="fas fa-shopping-cart"></i>
        <span>Cart</span>
        <span id="badge">0</span>
    </button>
</header>


       
    </section>

    <div class="products">
        <?php foreach($products as $p): ?>
        <div class="card">
            <img src="<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p>Rs <?= number_format($p['price']) ?></p>
            <button onclick="addCart(<?= $p['id'] ?>)">Add To Cart</button>
        </div>
        <?php endforeach; ?>
    </div>
</main>

<div class="overlay" id="overlay"></div>

<div class="cart-panel" id="cartPanel">
    <div class="cart-header">
        <div>
            <h2><i class="fa-solid fa-cart-shopping"></i> Your Cart</h2>
            <p id="cartCount">0 Items</p>
        </div>
        <button id="close">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <div class="cart-body" id="cartItems">
        </div>

    <div class="cart-footer">
        <div class="summary">
            <span>Total</span>
            <h3 id="total">Rs 0</h3>
        </div>
        <button class="checkout-btn" id="checkoutBtn">
            <i class="fa-solid fa-bag-shopping"></i> Checkout
        </button>
    </div>
</div>

<div id="msg"></div>

<script src="script.js"></script>


</body>
</html>